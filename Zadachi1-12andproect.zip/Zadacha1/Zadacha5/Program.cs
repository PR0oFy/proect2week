﻿using System;

namespace Zadacha5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool truevvod = false;

            do
            {
                try
                {
                    Console.WriteLine("Введите координаты коня x1 y1 и координаты фигуры x2 y2:");

                    // Чтение координат коня и фигуры
                    string[] vvod = Console.ReadLine().Split(' ');

                    if (vvod.Length != 2 || vvod[0].Length != 2 || vvod[1].Length != 2)
                    {
                        Console.WriteLine("Введены некорректные координаты. Повторите ввод.");
                        continue;
                    }

                    int coordinate_x1 = Convert.ToInt32(vvod[0][0] - 'a' + 1);
                    int coordinate_y1 = Convert.ToInt32(vvod[0][1] - '0');
                    int coordinate_x2 = Convert.ToInt32(vvod[1][0] - 'a' + 1);
                    int coordinate_y2 = Convert.ToInt32(vvod[1][1] - '0');

                    // Проверка корректности введенных координат
                    if (coordinate_x1 < 1 || coordinate_x1 > 8 || coordinate_y1 < 1 || coordinate_y1 > 8 || coordinate_x2 < 1 || coordinate_x2 > 8 || coordinate_y2 < 1 || coordinate_y2 > 8)
                    {
                        Console.WriteLine("Введены некорректные координаты. Повторите ввод.");
                    }
                    else if (coordinate_x1 == coordinate_x2 && coordinate_y1 == coordinate_y2)
                    {
                        Console.WriteLine("Конь и фигура не могут стоять на одной клетке. Повторите ввод.");
                    }
                    else
                    {
                        truevvod = true;

                        // Проверка, бьет ли конь фигуру за один ход
                        if (hodKonem(coordinate_x1, coordinate_y1, coordinate_x2, coordinate_y2))
                        {
                            Console.WriteLine("Конь сможет побить фигуру");
                        }
                        else
                        {
                            Console.WriteLine("Конь не сможет побить фигуру");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ошибка: " + ex.Message);
                }
            } while (!truevvod);

            Console.ReadKey();
        }

        // Проверка, может ли конь побить фигуру за один ход
        static bool hodKonem(int coordinate_x1, int coordinate_y1, int coordinate_x2, int coordinate_y2)
        {
            int cordX = Math.Abs(coordinate_x1 - coordinate_x2);
            int cordY = Math.Abs(coordinate_y1 - coordinate_y2);

            return (cordX == 2 && cordY == 1) || (cordX == 1 && cordY == 2);
        }
    }
}

