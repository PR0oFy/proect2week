﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace _2weekZadacha
{
    public partial class Form1 : Form
    {
        private const int targetRadius = 20;
        private const int targetCount = 10;
        private const string highscoreFile = "highscores.txt";

        private List<Rectangle> targets;
        private int score;
        private int timeLeft;
        private int time;
        private bool gameRunning;
        private bool modeTwoActive;
        private int modeTwoTimeLimit;
        private ComboBox modeComboBox;
        private const int gameTimeLimit = 30;
        private Timer gameTimer;
        private DateTime startTime;
        private DateTime endTime;

        public Form1()
        {
            InitializeComponent();
            InitializeGame();
            InitializeComboBox();

        }

        private void InitializeComboBox()
        {
            modeComboBox = new ComboBox();
            modeComboBox.Items.Add("Режим 1");
            modeComboBox.Items.Add("Режим 2");
            modeComboBox.SelectedIndex = 0; // По умолчанию выбран первый режим
            modeComboBox.SelectedIndexChanged += modeComboBox_SelectedIndexChanged;

            // Расположение ComboBox на форме
            modeComboBox.Location = new Point(10, 10);
            modeComboBox.Size = new Size(100, 20);

            this.Controls.Add(modeComboBox);
        }

        private void InitializeGame()
        {
            targets = new List<Rectangle>();
            score = 0;
            if (modeTwoActive)
            {
                timeLeft = modeTwoTimeLimit;
                startTime = DateTime.Now;
            }
            else
            {
                timeLeft = gameTimeLimit;
            }
            gameRunning = true;
            startTime = DateTime.Now;
            UpdateScoreLabel();
            StartGameTimer();
            CreateTargets();
            canvasPictureBox.Invalidate();
        }

        private void ShowGameOverDialog()
        {
            string username = InputUserName();
            endTime = DateTime.Now; // Сохраняем время окончания игры
            DialogResult result = MessageBox.Show($"Игра окончена, вы набрали {score} очков! Хотите сыграть еще раз?", "Game Over", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                InitializeGame();
            }
            else
            {
                SaveHighscore(username);
                Close();
            }
        }

        private void CreateTargets()
        {
            targets.Clear();

            Random random = new Random();
            if (!modeTwoActive)
            {
                for (int i = 0; i < targetCount; i++)
                {
                    Rectangle target;
                    int x = random.Next(targetRadius, canvasPictureBox.Width - targetRadius);
                    int y = random.Next(targetRadius, canvasPictureBox.Height - targetRadius);
                    target = new Rectangle(x, y, targetRadius * 2, targetRadius * 2);
                    targets.Add(target);
                }
            }
            else
            {
                for (int i = 0; i < 3; i++)
                {
                    Rectangle target;
                    int x = random.Next(targetRadius, canvasPictureBox.Width - targetRadius);
                    int y = random.Next(targetRadius, canvasPictureBox.Height - targetRadius);
                    target = new Rectangle(x, y, targetRadius * 2, targetRadius * 2);
                    targets.Add(target);
                }
            }

            canvasPictureBox.Invalidate(); // Обновляем PictureBox
        }

        private void canvasPictureBox_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            foreach (Rectangle target in targets)
            {
                g.FillEllipse(Brushes.Red, target);
            }
        }

        private void canvasPictureBox_MouseClick(object sender, MouseEventArgs e)
        {
            if (!gameRunning)
                return;

            bool targetHit = false; // Флаг для отслеживания попадания в мишень

            // Проверяем каждую мишень на пересечение с областью клика
            foreach (Rectangle target in targets)
            {
                if (target.IntersectsWith(new Rectangle(e.Location, new Size(1, 1))))
                {
                    targetHit = true; // Устанавливаем флаг попадания в мишень
                    score++; // Увеличиваем счетчик очков
                    UpdateScoreLabel(); // Обновляем метку счета

                    if (!modeTwoActive) // Если это первый режим
                    {
                        // Удаляем попавшую мишень
                        targets.Remove(target);

                        canvasPictureBox.Invalidate(); // Обновляем PictureBox

                        // Проверяем, закончились ли мишени или достигнут лимит очков
                        if (targets.Count == 0 || score == 10)
                        {
                            gameRunning = false;
                            ShowGameOverDialog();
                        }
                    }

                    break; // Прерываем цикл, так как уже попали в мишень
                }
            }

            if (modeTwoActive && targetHit) // Если это второй режим и было попадание в мишень
            {
                // Находим индекс попавшей мишени
                int index = targets.FindIndex(target => target.IntersectsWith(new Rectangle(e.Location, new Size(1, 1))));

                // Обновляем только попавшую мишень
                targets[index] = GenerateRandomTarget();

                canvasPictureBox.Invalidate(); // Обновляем PictureBox
            }
        }
        private Rectangle GenerateRandomTarget()
        {
            Random random = new Random();
            int x = random.Next(targetRadius, canvasPictureBox.Width - targetRadius);
            int y = random.Next(targetRadius, canvasPictureBox.Height - targetRadius);
            return new Rectangle(x, y, targetRadius * 2, targetRadius * 2);
        }

        private void modeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (modeComboBox.SelectedIndex == 0)
            {
                modeTwoActive = false;
                modeTwoTimeLimit = 0;
                timeLeft = gameTimeLimit;
                timeLeftLabel.Text = $"Времени осталось: {timeLeft} сек";
                targets.Clear();
                canvasPictureBox.Invalidate();
            }
            else if (modeComboBox.SelectedIndex == 1)
            {
                modeTwoActive = true;
                string input = "";
                using (var form = new Form())
                {
                    form.Size = new Size(300, 150);
                    form.StartPosition = FormStartPosition.CenterScreen;

                    var label = new Label
                    {
                        Text = "Выберите время для игры в режиме 2 (в секундах):",
                        Dock = DockStyle.Top
                    };

                    var textBox = new TextBox
                    {
                        Dock = DockStyle.Top,
                        Text = "30"
                    };

                    var okButton = new Button
                    {
                        Text = "OK",
                        DialogResult = DialogResult.OK,
                        Dock = DockStyle.Bottom
                    };

                    form.Controls.AddRange(new Control[] { label, textBox, okButton });

                    if (form.ShowDialog() == DialogResult.OK)
                    {
                        input = textBox.Text;
                    }
                }

                if (int.TryParse(input, out int result))
                {
                    time = result;
                    modeTwoTimeLimit = result;
                    timeLeft = modeTwoTimeLimit;
                    timeLeftLabel.Text = $"Времени осталось: {timeLeft} сек";
                    score = 0;
                    UpdateScoreLabel();
                    targets.Clear();
                    CreateTargets();
                    canvasPictureBox.Invalidate();
                }
                else
                {
                    MessageBox.Show("Вы ввели некорректное значение времени. Игра будет начата с временем по умолчанию (30 секунд).");
                    modeTwoTimeLimit = 30;
                    timeLeft = modeTwoTimeLimit;
                    timeLeftLabel.Text = $"Времени осталось: {timeLeft} сек";
                    score = 0;
                    UpdateScoreLabel();
                    targets.Clear();
                    CreateTargets();
                    canvasPictureBox.Invalidate();
                }
            }

            InitializeGame(); // Добавляем инициализацию игры при смене режима
        }

        private void UpdateScoreLabel()
        {
            scoreLabel.Text = $"Очки: {score}";
        }

        private void StartGameTimer()
        {
            if (gameTimer != null)
            {
                gameTimer.Stop();
                gameTimer.Dispose();
            }

            gameTimer = new Timer();
            gameTimer.Interval = 1000; // 1 секунда
            gameTimer.Tick += (sender, e) =>
            {
                if (timeLeft > 0)
                {
                    timeLeft--;
                    timeLeftLabel.Text = $"Времени осталось: {timeLeft} сек";
                }
                else
                {
                    gameTimer.Stop();
                    ShowGameOverDialog();
                }
            };
            gameTimer.Start();
        }

        private void SaveHighscore(string username)
        {
            if (!string.IsNullOrWhiteSpace(username) && !username.Equals("Anonymous", StringComparison.OrdinalIgnoreCase))
            {
                string highscoreEntry = $"{DateTime.Now}, Игрок: {username}, Очки: {score}, Время: {time} секунды";
                File.AppendAllLines(highscoreFile, new string[] { highscoreEntry });
            }
        }
        private TimeSpan GetElapsedTime()
        {
            return DateTime.Now - startTime;
        }


        private string InputUserName()
        {
            using (var form = new Form())
            {
                form.Size = new Size(300, 150);
                form.StartPosition = FormStartPosition.CenterScreen;

                var label = new Label
                {
                    Text = "Введите своё имя (от 3 до 10 символов, только буквы и цифры):",
                    Dock = DockStyle.Top
                };

                var textBox = new TextBox
                {
                    Dock = DockStyle.Top,
                    MaxLength = 10
                };

                var okButton = new Button
                {
                    Text = "OK",
                    DialogResult = DialogResult.OK,
                    Dock = DockStyle.Bottom
                };

                form.Controls.AddRange(new Control[] { label, textBox, okButton });

                if (form.ShowDialog() == DialogResult.OK)
                {
                    return textBox.Text;
                }
            }
            return "";
        }


    }
}
