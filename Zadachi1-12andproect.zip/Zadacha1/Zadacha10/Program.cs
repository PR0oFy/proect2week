﻿using System;


namespace Zadacha10
{


    // Основной класс программы
    class Program
    {
        // Основной метод программы
        static void Main()
        {
            Console.WriteLine("Введите тип фигуры (ладья, слон, король, ферзь):");
            string typeFigure = Console.ReadLine().ToLower();

            Random random = new Random();
            char bukva1 = (char)('a' + random.Next(8));
            char cifra1 = (char)('1' + random.Next(8));

            char bukva2 = (char)('a' + random.Next(8));
            char cifra2 = (char)('1' + random.Next(8));

            string coordinate1 = $"{bukva1}{cifra1}";
            string coordinate2 = $"{bukva2}{cifra2}";

            Console.WriteLine($"Сгенерированы координаты полей: {coordinate1}, {coordinate2}");

            switch (typeFigure)
            {
                case "ладья":
                    RokCheck(coordinate1, coordinate2);
                    break;

                case "слон":
                    BishopCheck(coordinate1, coordinate2);
                    break;

                case "король":
                    KingCheck(coordinate1, coordinate2);
                    break;

                case "ферзь":
                    QueenCheck(coordinate1, coordinate2);
                    break;

                default:
                    Console.WriteLine("Некорректный тип фигуры.");
                    break;
            }

            Console.ReadLine();
        }

        // Проверка для ладьи
        static void RokCheck(string coordinate1, string coordinate2)
        {
            if (coordinate1[0] != coordinate2[0] && coordinate1[1] != coordinate2[1])
            {
                Console.WriteLine("Ладья не угрожает полю.");
            }
            else
            {
                Console.WriteLine("Ладья угрожает полю.");
            }
        }

        // Проверка для слона
        static void BishopCheck(string coordinate1, string coordinate2)
        {
            int diff1 = Math.Abs(coordinate1[0] - coordinate2[0]);
            int diff2 = Math.Abs(coordinate1[1] - coordinate2[1]);

            if (diff1 != diff2)
            {
                Console.WriteLine("Слон не угрожает полю.");
            }
            else
            {
                Console.WriteLine("Слон угрожает полю.");
            }
        }

        // Проверка для короля
        static void KingCheck(string coordinate1, string coordinate2)
        {
            int diff1 = Math.Abs(coordinate1[0] - coordinate2[0]);
            int diff2 = Math.Abs(coordinate1[1] - coordinate2[1]);

            if (diff1 <= 1 && diff2 <= 1)
            {
                Console.WriteLine("Король может попасть на поле.");
            }
            else
            {
                Console.WriteLine("Король не может попасть на поле одним ходом.");
            }
        }

        // Проверка для ферзя
        static void QueenCheck(string coordinate1, string coordinate2)
        {
            int diff1 = Math.Abs(coordinate1[0] - coordinate2[0]);
            int diff2 = Math.Abs(coordinate1[1] - coordinate2[1]);

            if (coordinate1[0] != coordinate2[0] && coordinate1[1] != coordinate2[1] && diff1 != diff2)
            {
                Console.WriteLine("Ферзь не угрожает полю.");
            }
            else
            {
                Console.WriteLine("Ферзь угрожает полю.");
            }
        }
    }
}