﻿using System;

namespace Zadacha8
{
    class Program
    {
        // Запрос координат полей, проверка на корректность введенных координат и цвета полей
        static void Main()
        {
            Console.WriteLine("Введите координаты первого поля (например, a1):");
            string coordinate_1 = Console.ReadLine();

            Console.WriteLine("Введите координаты второго поля (например, b2):");
            string coordinate_2 = Console.ReadLine();

            if (IsValidField(coordinate_1) && IsValidField(coordinate_2))
            {
                bool color = CheckFieldColor(coordinate_1, coordinate_2);

                Console.WriteLine(color ? "Поля одного цвета." : "Поля разного цвета.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Некорректные координаты полей. Введите корректные значения от a1 до h8.");
                Console.ReadKey();
            }
        }

        // Проверка корректности координат поля
        static bool IsValidField(string coordinate)
        {
            if (coordinate.Length == 2)
            {
                char bukvy = coordinate[0];
                char cifry = coordinate[1];

                return (bukvy >= 'a' && bukvy <= 'h') && (cifry >= '1' && cifry <= '8');
            }

            return false;
        }

        // Проверка, являются ли поля одного цвета
        static bool CheckFieldColor(string coordinate_1, string coordinate_2)
        {
            int sum1 = coordinate_1[0] + coordinate_1[1];
            int sum2 = coordinate_2[0] + coordinate_2[1];

            return sum1 % 2 == sum2 % 2;
        }
    }
}
