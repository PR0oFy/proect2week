﻿using System;

namespace Zadacha9
{
    class Chess
    {
        static void Main()
        {
            Console.WriteLine("Введите исходные данные:");
            string input = Console.ReadLine();

            string[] inputArray = input.Split(' ');

            if (inputArray.Length != 5)
            {
                Console.WriteLine("Неверное количество элементов.");
                Console.WriteLine("Введите данные в формате: фигураБелая координатыБелойФигуры фигураЧерная координатыЧернойФигуры координатыЦаели");
                Console.ReadKey();
                return;
            }

            if (!TryParseCoordinates(inputArray[1], out int x1, out int y1) ||
                !TryParseCoordinates(inputArray[3], out int x2, out int y2) ||
                !TryParseCoordinates(inputArray[4], out int x3, out int y3))
            {
                Console.WriteLine("Ошибка в формате координат. Введите координаты от a1 до h8.");
                Console.ReadKey();
                return;
            }

            string whitePiece = inputArray[0];
            string blackPiece = inputArray[2];

            string result = GetResult(whitePiece, x1, y1, blackPiece, x2, y2, x3, y3);

            Console.WriteLine($"Результат: {result}");
            Console.ReadKey();
        }

        static bool TryParseCoordinates(string coordinates, out int x, out int y)
        {
            x = 0;
            y = 0;

            if (coordinates.Length != 2)
                return false;

            char file = coordinates[0];
            char rank = coordinates[1];

            if (file < 'a' || file > 'h' || rank < '1' || rank > '8')
                return false;

            x = file - 'a' + 1;

            if (!int.TryParse(rank.ToString(), out y))
                return false;

            return true;
        }

        static string GetResult(string whitePiece, int x1, int y1, string blackPiece, int x2, int y2, int x3, int y3)
        {
            if (!IsValidChessboardPosition(x1, y1) || !IsValidChessboardPosition(x2, y2) || !IsValidChessboardPosition(x3, y3))
            {
                return "Неверные координаты. Введите координаты от a1 до h8.";
            }

            switch (whitePiece.ToLower())
            {
                case "ладья":
                    if (CanRookReachDestination(x1, y1, x3, y3))
                    {
                        if (CanBlackPieceCapture(whitePiece, x3, y3, blackPiece, x2, y2))
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}, но будет съеден фигурой {blackPiece} на следующем ходу";
                        else
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}";
                    }
                    else
                        return $"{whitePiece} не может дойти до {GetChessCoordinates(x3, y3)}";
                case "конь":
                    if (CanKnightReachDestination(x1, y1, x3, y3))
                    {
                        if (CanBlackPieceCapture(whitePiece, x3, y3, blackPiece, x2, y2))
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}, но будет съеден фигурой {blackPiece} на следующем ходу";
                        else
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}";
                    }
                    else
                        return $"{whitePiece} не может дойти до {GetChessCoordinates(x3, y3)}";
                case "слон":
                    if (CanBishopReachDestination(x1, y1, x3, y3))
                    {
                        if (CanBlackPieceCapture(whitePiece, x3, y3, blackPiece, x2, y2))
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}, но будет съеден фигурой {blackPiece} на следующем ходу";
                        else
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}";
                    }
                    else
                        return $"{whitePiece} не может дойти до {GetChessCoordinates(x3, y3)}";
                case "ферзь":
                    if (CanQueenReachDestination(x1, y1, x3, y3))
                    {
                        if (CanBlackPieceCapture(whitePiece, x3, y3, blackPiece, x2, y2))
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}, но будет съеден фигурой {blackPiece} на следующем ходу";
                        else
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}";
                    }
                    else
                        return $"{whitePiece} не может дойти до {GetChessCoordinates(x3, y3)}";
                case "король":
                    if (CanKingReachDestination(x1, y1, x3, y3))
                    {
                        if (CanBlackPieceCapture(whitePiece, x3, y3, blackPiece, x2, y2))
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}, но будет съеден фигурой {blackPiece} на следующем ходу";
                        else
                            return $"{whitePiece} дойдет до {GetChessCoordinates(x3, y3)}";
                    }
                    else
                        return $"{whitePiece} не может дойти до {GetChessCoordinates(x3, y3)}";
                default:
                    return "Неверное название белой фигуры.";
            }
        }

        static bool IsValidChessboardPosition(int x, int y)
        {
            return x >= 1 && x <= 8 && y >= 1 && y <= 8;
        }

        static bool CanRookReachDestination(int x1, int y1, int x3, int y3)
        {
            return x1 == x3 || y1 == y3;
        }

        static bool CanKnightReachDestination(int x1, int y1, int x3, int y3)
        {
            return Math.Abs(x1 - x3) == 2 && Math.Abs(y1 - y3) == 1 || Math.Abs(x1 - x3) == 1 && Math.Abs(y1 - y3) == 2;
        }

        static bool CanBishopReachDestination(int x1, int y1, int x3, int y3)
        {
            return Math.Abs(x1 - x3) == Math.Abs(y1 - y3);
        }

        static bool CanQueenReachDestination(int x1, int y1, int x3, int y3)
        {
            return CanRookReachDestination(x1, y1, x3, y3) || CanBishopReachDestination(x1, y1, x3, y3);
        }

        static bool CanKingReachDestination(int x1, int y1, int x3, int y3)
        {
            return Math.Abs(x1 - x3) <= 1 && Math.Abs(y1 - y3) <= 1;
        }

        static bool CanBlackPieceCapture(string whitePiece, int x, int y, string blackPiece, int x2, int y2)
        {
            switch (blackPiece.ToLower())
            {
                case "ладья":
                    return CanRookReachDestination(x2, y2, x, y);
                case "конь":
                    return CanKnightReachDestination(x2, y2, x, y);
                case "слон":
                    return CanBishopReachDestination(x2, y2, x, y);
                case "ферзь":
                    return CanQueenReachDestination(x2, y2, x, y);
                case "король":
                    return CanKingReachDestination(x2, y2, x, y);
                default:
                    return false;
            }
        }

        static string GetChessCoordinates(int x, int y)
        {
            char file = (char)('a' + x - 1);
            return $"{file}{y}";
        }
    }
}