﻿using System;

class Program
{
    static int MagHP = 500;
    static int BossHP = 1000;
    static bool DopSkills = false;
    static double AttackMultiplier = 1.0;
    static int Damage = 0;

    static void Main()
    {
        Console.WriteLine("Добро пожаловать, паучок!");
        Console.WriteLine("Босс появился! Начинаем бой!");

        while (MagHP > 0 && BossHP > 0)
        {
            PrintCurrentHealth();
            PrintMenu();

            if (int.TryParse(Console.ReadLine(), out int choice))
            {
                HandlePlayerChoice(choice);
                if (choice != 2) // Проверяем, не выбрана ли вторая способность (Паучье чутьё)
                    BossAttack();
            }
            else
            {
                Console.WriteLine("Неверный ввод. Пропуск хода.");
            }
        }

        if (MagHP <= 0)
        {
            Console.WriteLine("Вы проиграли. Босс победил.");
            Console.ReadKey();
        }
        else
        {
            Console.WriteLine("Поздравляем! Вы победили босса и освободили мир от его тьмы.");
            Console.ReadKey();
        }
    }

    static void PrintCurrentHealth()
    {
        Console.WriteLine($"Текущее здоровье игрока: {MagHP}");
        Console.WriteLine($"Текущее здоровье босса: {BossHP}");
    }

    static void PrintMenu()
    {
        Console.WriteLine("Выберите заклинание:");
        Console.WriteLine("1. Атака паутиной - Исполняет трюки параллельно нанося атаки (урон 150 HP)");
        Console.WriteLine("2. Паучье чутьё - Паучок 100% увернется от атаки босса и кушает сэндвич (босс промахивается, восполняет 200 HP )");
        if (!DopSkills)
        {
            Console.WriteLine("3. Подарок от Тони Старка - Надевается усовершенствованный костюм Человек-Паук ( Используется 1 раз, даёт доступ к 4-ой и 5-ой способности, восполняет 100 HP)");
        }
        else
        {
            Console.WriteLine("3. Подарок от Тони Старка (уже использовано)");
            Console.WriteLine("4. Паучьи лапы - Из костюма вылезают лапы (дают бонус к атаке на 10%)");
            Console.WriteLine("5. Шок-Паутина - атакует паутиной с электричеством (босс пропускает ход, урон атаки 200 HP)");
        }
    }

    static void HandlePlayerChoice(int choice)
    {
        switch (choice)
        {
            case 1:
                Damage = (int)(150 * AttackMultiplier);
                BossHP -= Damage;
                Console.WriteLine($"Вы использовали Атаку паутиной. Босс получает {Damage} урона.");
                Damage = 0;
                break;
            case 2:
                MagHP += 200;
                Console.WriteLine("Вы использовали Паучье чутьё. Вы увернулись от атаки босса и восполнили 200 HP.");
                break;
            case 3:
                if (!DopSkills)
                {
                    DopSkills = true;
                    MagHP += 100;
                    Console.WriteLine("Вы использовали Подарок от Тони Старка. Получено 100 HP.");
                }
                else
                {
                    Console.WriteLine("У вас уже есть доступ ко всем способностям.");
                }
                break;
            case 4:
                if (DopSkills)
                {
                    AttackMultiplier += 0.1;
                    Console.WriteLine("Вы использовали Паучьи лапы. Ваша атака усилилась на 10%.");
                }
                else
                {
                    Console.WriteLine("Невозможно использовать эту способность сейчас.");
                }
                break;
            case 5:
                if (DopSkills)
                {
                    Damage = (int)(200 * AttackMultiplier);
                    BossHP -= Damage;
                    Console.WriteLine($"Вы использовали Шок-Паутина. Босс пропускает ход и получает {Damage} урона.");
                    Damage = 0;
                }
                else
                {
                    Console.WriteLine("Невозможно использовать эту способность сейчас.");
                }
                break;
            default:
                Console.WriteLine("Неверный выбор.");
                break;
        }
    }

    static void BossAttack()
    {
        Random rnd = new Random();
        int attackType = rnd.Next(1, 4); // Генерация случайного типа атаки босса

        switch (attackType)
        {
            case 1:
                Console.WriteLine("Босс атакует мощным ударом! (урон 200 HP)");
                MagHP -= 200;
                break;
            case 2:
                Console.WriteLine("Босс использует темную магию! (урон 150 HP)");
                MagHP -= 150;
                break;
            case 3:
                Console.WriteLine("Босс вызывает подкрепление! (восполняет 100 HP)");
                BossHP += 100;
                break;
            default:
                break;
        }
    }
}
