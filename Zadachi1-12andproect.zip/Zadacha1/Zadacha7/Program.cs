﻿using System;
using System.Collections.Generic;
using System.IO;

class Program
{

    static void Main()
    {
        Console.CursorVisible = false;

        string[] lines = File.ReadAllLines("map.txt");

        int playerStroka = 1;
        int playerCollonka = 7;

        Console.Clear();
        foreach (string line in lines)
        {
            Console.WriteLine(line);
        }

        List<Tuple<int, int>> route = new List<Tuple<int, int>>();
        bool showPuti = false;
        while (true)
        {
            InfoAboutLaberient(lines, route, showPuti);

            Console.SetCursorPosition(playerCollonka, playerStroka);
            Console.Write("■");

            ConsoleKeyInfo keyInfo = Console.ReadKey();
            ConsoleKey key = keyInfo.Key;

            Console.SetCursorPosition(playerCollonka, playerStroka);
            Console.Write(' ');

            int newPlayerStroka = playerStroka;
            int newPlayerCollonka = playerCollonka;

            if (key == ConsoleKey.UpArrow && CheckStenka(lines[playerStroka - 1][playerCollonka]))
            {
                newPlayerStroka--;
            }
            else if (key == ConsoleKey.DownArrow && CheckStenka(lines[playerStroka + 1][playerCollonka]))
            {
                newPlayerStroka++;
            }
            else if (key == ConsoleKey.LeftArrow && CheckStenka(lines[playerStroka][playerCollonka - 1]))
            {
                newPlayerCollonka--;
            }
            else if (key == ConsoleKey.RightArrow && CheckStenka(lines[playerStroka][playerCollonka + 1]))
            {
                newPlayerCollonka++;
            }

            if (lines[newPlayerStroka][newPlayerCollonka] == 'F')
            {
                Console.Clear();
                foreach (string line in lines)
                {
                    Console.WriteLine(line);
                }

                Console.WriteLine("Поздравляем! Вы прошли лабиринт!");
                Console.ReadKey();
                break;
            }

            if (CheckStenka(lines[newPlayerStroka][newPlayerCollonka]))
            {
                route.Add(new Tuple<int, int>(playerStroka, playerCollonka));
                playerStroka = newPlayerStroka;
                playerCollonka = newPlayerCollonka;
            }

            if (key == ConsoleKey.Escape)
            {
                break;
            }

            // Добавляем проверку для клавиши F4
            if (key == ConsoleKey.F4)
            {
                showPuti = !showPuti;
            }
        }

        Console.CursorVisible = true;
    }

    // Отображение текущего состояния лабиринта с учетом маршрута и настроек отображения точек
    static void InfoAboutLaberient(string[] lines, List<Tuple<int, int>> route, bool showPuti)
    {
        Console.Clear();

        for (int i = 0; i < lines.Length; i++)
        {
            char[] lineChars = lines[i].ToCharArray();

            for (int j = 0; j < lineChars.Length; j++)
            {
                Console.SetCursorPosition(j, i);

                if (lineChars[j] == '·' && !showPuti)
                {

                }

                else
                {
                    Console.Write(lineChars[j]);
                }
            }
        }
    }

    // Проверка, можно ли двигаться на клетку с данным символом
    static bool CheckStenka(char symbol)
    {
        return symbol != '═' && symbol != '║' && symbol != '╣' && symbol != '╠' && symbol != '╦' && symbol != '╩'
            && symbol != '╔' && symbol != '╗' && symbol != '╚' && symbol != '╝' && symbol != '╬';
    }
}