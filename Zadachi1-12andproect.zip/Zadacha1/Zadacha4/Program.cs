﻿using System;

internal class Program
{
    static void Main(string[] args)
    {
        bool truevvod = false;

        do
        {
            try
            {
                Console.WriteLine("Введите координаты короля x1 y1 и координаты фигуры x2 y2:(как пример, a4 c5)");

                string[] vvod = Console.ReadLine().Split(' ');

                if (vvod.Length != 2 || vvod[0].Length != 2 || vvod[1].Length != 2)
                {
                    Console.WriteLine("Введены некорректные координаты. Повторите ввод.(как пример, a4 c5)");
                    continue;
                }

                int coordinate_x1 = Convert.ToInt32(vvod[0][0] - 'a' + 1);
                int coordinate_y1 = Convert.ToInt32(vvod[0][1] - '0');
                int coordinate_x2 = Convert.ToInt32(vvod[1][0] - 'a' + 1);
                int coordinate_y2 = Convert.ToInt32(vvod[1][1] - '0');

                if (coordinate_x1 < 1 || coordinate_x1 > 8 || coordinate_y1 < 1 || coordinate_y1 > 8 || coordinate_x2 < 1 || coordinate_x2 > 8 || coordinate_y2 < 1 || coordinate_y2 > 8)
                {
                    Console.WriteLine("Введены некорректные координаты. Повторите ввод.(как пример, a4 c5)");
                }
                else if (Math.Abs(coordinate_x1 - coordinate_x2) <= 1 && Math.Abs(coordinate_y1 - coordinate_y2) <= 1)
                {
                    Console.WriteLine("Король сможет побить фигуру");
                    Console.ReadKey();
                }
                else
                {
                    Console.WriteLine("Король не сможет побить фигуру");
                    Console.ReadKey();
                }

                truevvod = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
        } while (!truevvod);
    }
}