﻿using System;

namespace Zadacha2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool truevvod = false;

            do
            {
                try
                {
                    Console.WriteLine("\"Введите координаты ладьи x1 y1 и координаты фигуры x2 y2 (как пример, a4 c5):");

                    // Чтение координат ладьи и фигуры
                    string[] vvod = Console.ReadLine().Split(' ');

                    if (vvod.Length != 2 || vvod[0].Length != 2 || vvod[1].Length != 2)
                    {
                        Console.WriteLine("Введены некорректные координаты. Повторите ввод.(попробуй a4 c5)");
                        continue;
                    }
                    // переобразуем координаты в числа и проделываем данную операцию (и там и там 97 в ASCII-коде)arr_cord[0][0] - 'a' + 1 
                    int coordinate_x1 = Convert.ToInt32(vvod[0][0] - 'a' + 1);
                    int coordinate_y1 = Convert.ToInt32(vvod[0][1] - '0');
                    int coordinate_x2 = Convert.ToInt32(vvod[1][0] - 'a' + 1);
                    int coordinate_y2 = Convert.ToInt32(vvod[1][1] - '0');

                    // Проверка корректности введенных координат
                    if (coordinate_x1 < 1 || coordinate_x1 > 8 || coordinate_y1 < 1 || coordinate_y1 > 8 || coordinate_x2 < 1 || coordinate_x2 > 8 || coordinate_y2 < 1 || coordinate_y2 > 8)
                    {
                        Console.WriteLine("Введены некорректные координаты. Повторите ввод.");
                    }
                    else if (coordinate_x1 == coordinate_x2 && coordinate_y1 == coordinate_y2)
                    {
                        Console.WriteLine("Слон и фигура не могут стоять на одной клетке. Повторите ввод.");
                    }
                    else
                    {
                        {
                            truevvod = true;

                            // Проверка, может ли слон побить фигуру за один ход
                            bool CanOneHite = canonehite(coordinate_x1, coordinate_y1, coordinate_x2, coordinate_y2);

                            // Вывод результата
                            if (CanOneHite)
                            {
                                Console.WriteLine("Слон сможет побить фигуру");
                            }
                            else
                            {
                                Console.WriteLine("Слон не сможет побить фигуру");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Ошибка: " + ex.Message);
                }
            } while (!truevvod);

            Console.ReadKey();
        }

        // Проверка, может ли слон побить фигуру за один ход
        static bool canonehite(int coordinate_x1, int coordinate_y1, int coordinate_x2, int coordinate_y2)
        {
            // Проверка, находится ли фигура на одной диагонали со слоном
            return Math.Abs(coordinate_x1 - coordinate_x2) == Math.Abs(coordinate_y1 - coordinate_y2);
        }
    }
}
