﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;

namespace Zadacha11
{
    public partial class Form1 : Form
    {
        // Массив цветов для каждого блока 3x3
        Color[,] blockColors = {
            { Color.LightGray, Color.LightGoldenrodYellow, Color.LightGray },
            { Color.LightGoldenrodYellow, Color.LightGray, Color.LightGoldenrodYellow },
            { Color.LightGray, Color.LightGoldenrodYellow, Color.LightGray }
        };

        private TextBox[,] textBoxes;
        private readonly string[] sudokuFiles = { "sudoku1.txt", "sudoku2.txt", "sudoku3.txt", "sudoku4.txt", "sudoku5.txt" };


        public Form1()
        {
            InitializeComponent();
            InitializeTextBoxes();
            ColorAllBlocks();
        }

        private void InitializeTextBoxes()
        {
            // Создаем и располагаем TextBox'ы на форме
            textBoxes = new TextBox[9, 9];
            int textBoxSize = 30;

            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    TextBox textBox = new TextBox();
                    textBox.Size = new Size(textBoxSize, textBoxSize);
                    textBox.Location = new Point(j * (textBoxSize + 3), i * (textBoxSize + 3));
                    textBox.TextAlign = HorizontalAlignment.Center;

                    // Запрещаем редактирование TextBox'ов (они будут только для вывода)
                    textBox.ReadOnly = true;

                    textBox.Multiline = true;

                    textBox.Font = new Font(textBox.Font.FontFamily, 16);

                    // Добавляем TextBox на форму и в массив textBoxes
                    this.Controls.Add(textBox);
                    textBoxes[i, j] = textBox;

                }
            }
        }

        // Метод для установки цвета внутри блока 3x3
        private void ColorBlock(int blockRow, int blockCol)
        {
            for (int i = blockRow * 3; i < (blockRow + 1) * 3; i++)
            {
                for (int j = blockCol * 3; j < (blockCol + 1) * 3; j++)
                {
                    textBoxes[i, j].BackColor = blockColors[blockRow, blockCol];
                    textBoxes[i, j].BorderStyle = BorderStyle.FixedSingle; // Стиль границы между ячейками
                }
            }
        }

        // Метод для перекраски всех блоков
        private void ColorAllBlocks()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 3; j++)
                {
                    ColorBlock(i, j);
                }
            }
        }

        private void GenerateSudoku()
        {
            // Выбираем случайный файл
            Random random = new Random();
            string randomSudokuFile = sudokuFiles[random.Next(sudokuFiles.Length)];

            int[,] sudoku = ReadSudokuFromFile(randomSudokuFile);
            DisplaySudoku(sudoku);
        }

        private int[,] ReadSudokuFromFile(string filePath)
        {
            int[,] sudoku = new int[9, 9];
            string[] lines = File.ReadAllLines(filePath);

            for (int i = 0; i < 9; i++)
            {
                string[] numbers = lines[i].Split(' ');
                for (int j = 0; j < 9; j++)
                {
                    sudoku[i, j] = int.Parse(numbers[j]);
                }
            }

            return sudoku;
        }

        private void DisplaySudoku(int[,] sudoku)
        {
            for (int i = 0; i < 9; i++)
            {
                for (int j = 0; j < 9; j++)
                {
                    textBoxes[i, j].Text = sudoku[i, j].ToString();
                }
            }
        }

        private void btnGenerateSudoku_Click(object sender, EventArgs e)
        {
            GenerateSudoku();
        }
    }
}
